
import { EXPERIENCES, SKILLS, EDUCATION, BIO_SUMMARY } from '../constants';

/**
 * Client-side service to interact with the backend Gemini API
 */
export async function generateResponse(userInput: string): Promise<string> {
  const systemInstruction = `
    Tu es l'assistant virtuel du CV interactif d'Eric Doidi.
    Ton rôle est d'informer les recruteurs et partenaires sur son parcours.

    DONNÉES DU CV :
    - BIO : ${BIO_SUMMARY}
    - EXPÉRIENCES : ${JSON.stringify(EXPERIENCES)}
    - COMPÉTENCES : ${JSON.stringify(SKILLS)}
    - FORMATION : ${JSON.stringify(EDUCATION)}

    CONSIGNES :
    - Sois professionnel, concis et chaleureux.
    - Réponds en français.
    - Si tu ne connais pas la réponse, suggère de contacter Eric directement via l'onglet contact.
    - Ne sors pas du cadre professionnel.
  `;

  try {
    const response = await fetch("/api/gemini/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ 
        prompt: userInput,
        systemInstruction: systemInstruction
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || "Une erreur est survenue.");
    }

    const data = await response.json();
    return data.text || "Désolé, je n'ai pas pu générer de réponse.";
  } catch (error) {
    console.error("Gemini Service Error:", error);
    return "Désolé, une erreur technique m'empêche de répondre. Veuillez réessayer plus tard ou contacter Eric directement.";
  }
}
