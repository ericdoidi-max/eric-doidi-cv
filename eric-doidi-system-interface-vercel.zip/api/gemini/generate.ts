import { GoogleGenAI } from "@google/genai";

// Format Vercel Edge/Node serverless function (Node runtime par défaut)
export default async function handler(req: any, res: any) {
  // CORS minimal et méthode
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  // Body parsing (Vercel le fait automatiquement si Content-Type: application/json)
  const { prompt, systemInstruction } = req.body || {};

  if (!prompt) {
    return res.status(400).json({ error: "Missing 'prompt' in request body" });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "GEMINI_API_KEY is not configured on the server" });
  }

  try {
    const ai = new GoogleGenAI({ apiKey });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction:
          systemInstruction ||
          "Tu es l'assistant virtuel d'Eric Doidi. Réponds aux questions sur son parcours de manière professionnelle.",
      },
    });

    return res.status(200).json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return res.status(500).json({
      error: error?.message || "Failed to generate content",
    });
  }
}
